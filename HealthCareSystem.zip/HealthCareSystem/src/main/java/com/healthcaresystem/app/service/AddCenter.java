package com.healthcaresystem.app.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.healthcaresystem.app.dto.Appointment;
import com.healthcaresystem.app.dto.DiagnosticCenter;
import com.healthcaresystem.app.dto.Test;

public class AddCenter {

	public void addCenter() {
		//Scanner sc = new Scanner(System.in);
		
		String centerName="";
		String location = "";
		int openingYear=0;
		List<Test> listOfTests = null;
		
//		System.out.println("Enter the Diagnostic Center Name: ");
//		centerName = sc.nextLine();
//		System.out.println("Enter 3 tests");
//		listOfTests = new ArrayList<Test>();
//		
//		for (int i = 0; i < 3; i++) {
//			System.out.println("Enter the Test Name: ");
//			String testName = sc.nextLine();
//			String testId = testName+"@123";
//			Test test = new Test(testId, testName);
//			listOfTests.add(test);
//		}
//		
//		System.out.println("Enter the location: ");
//		location = sc.nextLine();
//		
//		System.out.println("Enter the Opening Year: ");
//		openingYear = sc.nextInt();
		
		List<Appointment> appointmentList = new ArrayList<Appointment>();
		String centerId = "";
		//String centerId = centerName+"@123";
		DiagnosticCenter dc = new DiagnosticCenter(centerName, centerId, listOfTests, appointmentList, location, openingYear);
		HashMap<String, DiagnosticCenter> hm = new HashMap<String, DiagnosticCenter>();
		ArrayList<HashMap<String, DiagnosticCenter>> al = new ArrayList<HashMap<String,DiagnosticCenter>>();
		al.add(0,hm);
		n1(al);
		//n2(dc);
		Admin_Login al1 = new Admin_Login();
		al1.admin_menu();
	}
	
	public static void n1(ArrayList<HashMap<String, DiagnosticCenter>> al) {
		File path = new File("W:\\Health Care System\\HealthCareSystem\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(path);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			out.writeObject(al);
		} catch(Exception ex) {
			ex.printStackTrace();
		}	
	}
	
	public static void n2(DiagnosticCenter dc) {
		File path = new File("W:\\Health Care System\\HealthCareSystem\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		FileInputStream fis = null;
		FileOutputStream fos = null;
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		try {
			fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>)in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			hm.put(dc.getCenterId(),dc);
			al.set(0,hm);
			System.out.println("Diagnostic Center Id: "+dc.getCenterId());
			System.out.println("New Diagnostic Center added Successfully!!!");
			in.close();
			fis.close();
			
			fos = new FileOutputStream(path);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			out.writeObject(al);
			out.close();
			fos.close();
			return;
		}  catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}
