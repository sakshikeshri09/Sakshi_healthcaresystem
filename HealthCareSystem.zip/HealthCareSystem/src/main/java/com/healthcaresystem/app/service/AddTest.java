package com.healthcaresystem.app.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.healthcaresystem.app.dto.DiagnosticCenter;
import com.healthcaresystem.app.dto.Test;

public class AddTest {

	public void addTest() {
		
		ViewCentersDetails view = new ViewCentersDetails();
		view.displayCenter();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Diagnostic Center Id: ");
		String centerId = sc.next();
		
		File path = new File("W:\\Health Care System\\HealthCareSystem\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		FileInputStream fis = null;
		FileOutputStream fos = null;
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		
		try {
			fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>)in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			
			if(hm.containsKey(centerId))
			{
				System.out.println("Enter the number of test(s) to be added: ");
				int n = sc.nextInt();
				DiagnosticCenter dc = hm.get(centerId);
				List<Test> test = dc.getListOfTests();
				for(int i=0;i<n;i++)
				{
					System.out.println("Enter the test name: ");
					sc.nextLine();
					String testName = sc.nextLine();
					String testId = testName+"@123";
					Test t = new Test(testId, testName);
					test.add(t);
				}
				dc.setListOfTests(test);
				hm.put(centerId, dc);
				al.set(0, hm);
				in.close();
				fis.close();
				fos = new FileOutputStream(path);
				ObjectOutputStream out = new ObjectOutputStream(fos);
				out.writeObject(al);
				out.close();
				fos.close();
				System.out.println("New Test details has been successfully added!!!");
			}
			else
			{
				System.out.println("Diagnostic Center with Id: "+centerId+" doesn't exist!!!");
				System.out.println("Please Try Again!!!");
				addTest();
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		Admin_Login al1 = new Admin_Login();
		al1.admin_menu();
	}
}
