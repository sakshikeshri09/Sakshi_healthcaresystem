package com.healthcaresystem.app.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import com.healthcaresystem.app.dto.User;
import com.healthcaresystem.app.exe.MainClass;

public class User_Login {
	User user = null;
	Scanner sc = new Scanner(System.in);
	public void login() {
		
		System.out.println("-------------------------Enter your login credentials-----------------------");
		System.out.println("Enter your User Id: ");
		String userId = sc.next();
		System.out.println("Enter your passowrd: ");
		String pass = sc.next();
		
		File path = new File("W:\\Health Care System\\HealthCareSystem\\src\\main\\resources\\UserDetails.txt");
		FileInputStream fis = null;
		ArrayList<HashMap<String, User>> al = null;
		try {
			fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			al = (ArrayList<HashMap<String, User>>)in.readObject();
			HashMap<String, User> hm = al.get(0);
			if(hm.containsKey(userId))
			{
				user = hm.get(userId);
				if(user.getUserPassword().equals(pass))
				{
					System.out.println("Logged in Successfully!!!");
					System.out.println("-----------------------------Welcome "+user.getUserName().toUpperCase()+" !--------------------------------");
					user_menu();
				}
				else
				{
					System.out.println("Invalid Credentials!!!");
					login();
				}
			}
			else
			{
				System.out.println("Invalid Credentials!!!");
				login();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void user_menu() {
		System.out.println("1. View Diagnostic Centers");
		System.out.println("2. Take Appointment");
		System.out.println("3. Logout");
		int n = sc.nextInt();
		switch(n) {
		
		case 1:		ViewCentersDetails view = new ViewCentersDetails();
					view.displayCenter();
					user_menu();
					break;
					
		case 2:		TakeAppointment take = new TakeAppointment();
					take.takeAppointment(user.getUserId());
					user_menu();
					break;		
					
		case 3:		System.out.println("Logged out Successfully!!!");
					MainClass main = new MainClass();
					main.main(null);
					break;
		
		default:	System.out.println("Wrong Input!!");
					user_menu();
					break;
		}
	}
}
