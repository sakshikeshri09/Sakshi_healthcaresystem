package com.healthcaresystem.app.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.healthcaresystem.app.dto.Appointment;
import com.healthcaresystem.app.dto.DiagnosticCenter;
import com.healthcaresystem.app.dto.Test;

public class TakeAppointment {

	public void takeAppointment(String uid) {
		
		ViewCentersDetails view = new ViewCentersDetails();
		view.displayCenter();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter the Diagnostic Center Id: ");
		String centerId = sc.next();
		
		File path = new File("W:\\Health Care System\\HealthCareSystem\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		FileInputStream fis = null;
		FileOutputStream fos = null;
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		
		try {
			fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>)in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			
			
			if(hm.containsKey(centerId))
			{
				DiagnosticCenter dc = hm.get(centerId);
				List<Test> test = dc.getListOfTests();
				
				int n = 0;
				for (Test i : test) {
					System.out.println(++n +". "+i.getTestId()+" "+i.getTestName());
				}
				
				System.out.println("Enter the test id from above list: ");
				sc.nextLine();
				String testId = sc.nextLine();
				
				List<Test> t = new ArrayList<Test>();
				int flag=0;
				for(Test i : test)
				{
					if(i.getTestId().equals(testId))
					{
						flag=1;
						t.add(i);
						break;
					}
				}
				
				if(flag==0)
				{
					System.out.println("The test doesn't exist!!!");
					System.out.println("Please try again!!!");
					takeAppointment(uid);
				}
				
				else {
					System.out.println("Enter date and time in format(DD-MM-YYYY HH:MM) between 10:00 to 18:00");
					String date = sc.nextLine();
					SimpleDateFormat sd = new SimpleDateFormat("dd-mm-yyyy hh:mm");
					Date d = sd.parse(date);
					String appointmentId = uid + "#123";
					boolean approved = false;
					
					Appointment appoint = new Appointment(uid, appointmentId, t, d, approved, dc);
					List<Appointment> ap = dc.getAppointmentList();
					ap.add(appoint);
					dc.setAppointmentList(ap);
					hm.put(centerId, dc);
					al.set(0, hm);
					
					in.close();
					fis.close();
					System.out.println("Appointment Request made Successfully!!!");
					fos = new FileOutputStream(path);
					ObjectOutputStream out = new ObjectOutputStream(fos);
					out.writeObject(al);
					System.out.println("Hello");
					out.close();
					fos.close();
				}
			}
			else
			{
				System.out.println("Diagnostic Center with Id: "+centerId+" doesn't exist!!!");
				System.out.println("Please Try Again!!!");
				takeAppointment(uid);
			}
			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}
