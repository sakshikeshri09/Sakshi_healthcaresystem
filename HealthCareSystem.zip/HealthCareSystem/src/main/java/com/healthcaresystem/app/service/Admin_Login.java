package com.healthcaresystem.app.service;

import java.util.Scanner;

import com.healthcaresystem.app.exe.MainClass;

public class Admin_Login {

	Scanner sc = new Scanner(System.in);
	static String admin_id="";
	
	public void login() {
		
		System.out.println("-------------------------Enter your login credentials-----------------------");
		System.out.println("Enter your Administrator Id: ");
		admin_id = sc.next();
		System.out.println("Enter your Password: ");
		String admin_pass = sc.next();
		if(admin_id.equals("rtvik") && admin_pass.equals("rtvik@123"))
		{
			System.out.println("Logged in Successfully!!!");
			admin_menu();
		}
		else
		{
			System.out.println("Wrong Credentials!!!");
			System.out.println("Please try again!");
			login();
		}
	}
	
	public void admin_menu() {
			System.out.println("-----------------------------Welcome "+admin_id.toUpperCase()+" !--------------------------------");
			System.out.println("1. View Diagnostic Centers");
			System.out.println("2. Add Diagnostic Center");
			System.out.println("3. Remove Diagnostic Center");
			System.out.println("4. Add Test Details");
			System.out.println("5. Remove Test Details");
			System.out.println("6. Logout");
			int n = sc.nextInt();
			switch(n) {
			
			case 1: ViewCentersDetails view = new ViewCentersDetails();
					view.displayCenter();
					admin_menu();
					break;
					
			case 2:	AddCenter addCenter = new AddCenter();
					addCenter.addCenter();
					break;
				
			case 3: RemoveCenter remove = new RemoveCenter();
					remove.removeCenter();
					break;
					
			case 4:	AddTest addTest = new AddTest();
					addTest.addTest();
					break;
				
			case 5: RemoveTest removeTest = new RemoveTest();
					removeTest.removeTest();
					break;
			
			case 6: System.out.println("Logged out Successfully!!!");
					MainClass main = new MainClass();
					main.main(null);
					break;
					
			default:System.out.println("Wrong Input!!");
					admin_menu();
					break;
			
			}
	}
}

