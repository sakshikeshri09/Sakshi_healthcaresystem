package com.healthcaresystem.app.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.healthcaresystem.app.dto.DiagnosticCenter;

public class ViewCentersDetails {

	public void displayCenter() {
		
		File path = new File("W:\\Health Care System\\HealthCareSystem\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		FileInputStream fis = null;
		FileOutputStream fos = null;
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		
		try {
			fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>)in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			
			for (Map.Entry m : hm.entrySet()) {
				System.out.println(m.getValue());
			}
			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}
