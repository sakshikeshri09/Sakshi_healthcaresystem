package com.healthcaresystem.app.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.healthcaresystem.app.dto.DiagnosticCenter;
import com.healthcaresystem.app.dto.User;

public class Register {

public void register() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("--------------------------Fill up the following details---------------------");
		
		int flag=0;
		String name = "";
		String pass = "";
		BigInteger phn = null;
		String email = "";
		String gender = "";
		int age = 0;
		do {
			System.out.println("Enter your name: ");
			//sc.nextLine();
			name = sc.nextLine();
			if(name_validate(name.trim()))
			{
				System.out.println("Enter your password: ");
				//sc.nextLine();
				pass = sc.nextLine();
				if(pass_validate(pass))
				{
					System.out.println("Enter your phone no.: ");
					phn = sc.nextBigInteger();
					if(phn_validate(phn))
					{
						System.out.println("Enter your email-id: ");
						sc.nextLine();
						email = sc.nextLine();
						System.out.println("Enter your gender(M/F): ");
						gender = sc.next();
						if(gender.equals("M") || gender.equals("F"))
						{
							System.out.println("Enter your age: ");
							age = sc.nextInt();
							if(age>0)
								flag=1;
						}
					}
				}
			}
			if(flag==0)	System.out.println("Enter the correct details!!!");
		} while (flag!=1);
		
		List<DiagnosticCenter> centerList = null;
//		String userId ="";
		String userId = name+"@123";
		User user = new User(userId, centerList, pass, name, phn, email, gender, age);
//		HashMap<String, User> hm = new HashMap<String, User>();
//		ArrayList<HashMap<String, User>> al = new ArrayList<HashMap<String,User>>();
//		al.add(0,hm);
//		m1(al);
		m2(user);
		
	}
	
	public static void m2(User user) {
		File path = new File("W:\\Health Care System\\HealthCareSystem\\src\\main\\resources\\UserDetails.txt");
		FileInputStream fis = null;
		FileOutputStream fos = null;
		ArrayList<HashMap<String, User>> al = null;
		try {
			fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			al = (ArrayList<HashMap<String, User>>) in.readObject();
			HashMap<String, User> hm = al.get(0);
			hm.put(user.getUserId(),user);
			al.set(0,hm);
			System.out.println(al);
			System.out.println("Your User Id: "+user.getUserId());
			System.out.println("Your Passowrd: "+user.getUserPassword());
			System.out.println("Registered Successfully!!!");
			in.close();
			fis.close();
			
			fos = new FileOutputStream(path);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			out.writeObject(al);
			out.close();
			fos.close();
			return;
		}  catch(Exception ex) {
			ex.printStackTrace();
		}
	}
			
	public boolean name_validate(String name) {
		if(name.charAt(0)>='A'&& name.charAt(0)<='Z')
			return true;
		return false;
	}
	
	public boolean pass_validate(String pass) {
		if(pass.length() >=8 && pass.length()<=14 ) {
			int num=0;
			int alpha=0;
			int spec=0;
			for(int i=0;i<pass.length();i++) {
				if((pass.charAt(i)>=65 && pass.charAt(i)<=90) || (pass.charAt(i)>=97 && pass.charAt(i)<=122))
				{
					alpha++;
				}
				else if(pass.charAt(i)>=48 && pass.charAt(i)<=57)
				{
					num++;
				}
				else
					spec++;
			}
			
			if(alpha>1 && num>0 && spec>0)
				return true;
		}
		return false;
	}
		
	public boolean phn_validate(BigInteger phn) {
		int digit=0;
		int intValueOfb1=phn.intValue();
		while(intValueOfb1!=0)
		{
			intValueOfb1=intValueOfb1/10;
			digit++;
		}
		if(digit==10)
			return true;
		return false;
	}
	

	public static void m1(ArrayList<HashMap<String, User>> al) {
		File path = new File("W:\\Health Care System\\HealthCareSystem\\src\\main\\resources\\UserDetails.txt");
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(path);
			ObjectOutputStream out = new ObjectOutputStream(fos);
			out.writeObject(al);
		} catch(Exception ex) {
			ex.printStackTrace();
		}	
	}
}
