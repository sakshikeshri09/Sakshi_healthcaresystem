package com.healthcaresystem.app.exe;

import java.util.Scanner;

import com.healthcaresystem.app.service.Admin_Login;
import com.healthcaresystem.app.service.Forg_Pass;
import com.healthcaresystem.app.service.User_Login;
import com.healthcaresystem.app.service.Register;

public class MainClass {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("-------------------------Welcome to Health Care System----------------------");
		System.out.println("Enter your User Role ");
		System.out.println("1. Admin");
		System.out.println("2. Customer");
		System.out.println("3. Exit");
		int n = sc.nextInt();
		//i= for options what to select
		int i=0;
		switch(n) {
		//Admin 
		case 1: 	System.out.println("------------------------------Select an option------------------------------");
					System.out.println("1. Login");
					System.out.println("2. Exit");
					int a = sc.nextInt();
					switch(a) {
					case 1:		Admin_Login al = new Admin_Login();
								al.login();
								break;
								
								
					case 2:		main(null);
								break;
					}
					
					break;
					
		//User			
		case 2:		do {	i=0;
							System.out.println("------------------------------Select an option------------------------------");
							System.out.println("1. Login");
							System.out.println("2. Register");
							System.out.println("3. Forgot Password");
							System.out.println("4. Exit");
							int c = sc.nextInt();
							switch(c) {
							case 1:		User_Login ul = new User_Login();
										ul.login();
										i=0;
										break;
			
							case 2:		Register r = new Register();
										r.register();
										i=2;
										break;
					
							case 3:		Forg_Pass fp = new Forg_Pass();
										fp.forgot();
										i=2;
										break;
							
							case 4:  	main(null);
										break;
							}
					}while(i==2);
		
					break;
		
		//Exit
		case 3:		return;
		
		default: 	System.out.println("Wrong Input!!!");
					main(null);
		
		}
	}

}
