package com.healthcaresystem.app.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import com.healthcaresystem.app.dto.DiagnosticCenter;
import com.healthcaresystem.app.dto.User;

public class RemoveCenter {

	public void removeCenter() {
		
		ViewCentersDetails view = new ViewCentersDetails();
		view.displayCenter();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Diagnostic Center Id: ");
		String centerId = sc.next();
		
		File path = new File("W:\\Health Care System\\HealthCareSystem\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		FileInputStream fis = null;
		FileOutputStream fos = null;
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		
		try {
			fis = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fis);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>)in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			
			if(hm.containsKey(centerId))
			{
				hm.remove(centerId);
				al.set(0, hm);
				in.close();
				fis.close();
				fos = new FileOutputStream(path);
				ObjectOutputStream out = new ObjectOutputStream(fos);
				out.writeObject(al);
				out.close();
				fos.close();
				System.out.println("Diagnostic Center has been successfully removed!!!");
			}
			else
			{
				System.out.println("Diagnostic Center with Id: "+centerId+" doesn't exist!!!");
				System.out.println("Please Try Again!!!");
				removeCenter();
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		Admin_Login al1 = new Admin_Login();
		al1.admin_menu();
	}
}
