package com.healthcaresystem.app.model;

import java.io.Serializable;
import java.util.List;

public class DiagnosticCenter implements Serializable {

	private String centerName;
	private String centerId;
	private List<Test> listOfTests;
	private List<Appointment> appointmentList;
	private String location;
	private int openingYear;
	
	public DiagnosticCenter(String centerName, String centerId, List<Test> listOfTests, List<Appointment> appointmentList, String location, int openingYear) {
		super();
		this.centerName = centerName;
		this.centerId = centerId;
		this.listOfTests = listOfTests;
		this.appointmentList = appointmentList;
		this.location = location;
		this.openingYear = openingYear;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getOpeningYear() {
		return openingYear;
	}
	public void setOpeningYear(int openingYear) {
		this.openingYear = openingYear;
	}
	public String getCenterName() {
		return centerName;
	}
	@Override
	public String toString() {
		return "DiagnosticCenter [centerName=" + centerName + ", centerId=" + centerId + ", listOfTests=" + listOfTests
				+ ", appointmentList=" + appointmentList + ", location=" + location + ", openingYear=" + openingYear
				+ "]";
	}
	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}
	public String getCenterId() {
		return centerId;
	}
	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}
	public List<Test> getListOfTests() {
		return listOfTests;
	}
	public void setListOfTests(List<Test> listOfTests) {
		this.listOfTests = listOfTests;
	}
	public List<Appointment> getAppointmentList() {
		return appointmentList;
	}
	public void setAppointmentList(List<Appointment> appointmentList) {
		this.appointmentList = appointmentList;
	}
}
