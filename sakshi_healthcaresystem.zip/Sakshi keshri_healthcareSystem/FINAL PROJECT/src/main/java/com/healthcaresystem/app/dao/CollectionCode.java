package com.healthcaresystem.app.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class CollectionCode{

	
	public ObjectInputStream dc_read(File f)
	{
		ObjectInputStream ois=null;
		//String path="C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt";
	//	f= new File(path);
		try {
		FileInputStream fis=new FileInputStream(f);
		 ois= new ObjectInputStream(fis);;
		
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ois;
		
		
	}
	
	public ObjectOutputStream dc_write(File path)
	{
		ObjectOutputStream oos=null;
	//	String path="C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt";
		//f= new File(path);
		try {
		FileOutputStream fos=new FileOutputStream(path);
		 oos= new ObjectOutputStream(fos);;
		
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return oos;
		
		
	}
	
	public ObjectInputStream user_Read(File path)
	{
		ObjectInputStream oos=null;
	//	String path="C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt";
		//f= new File(path);
		try {
		FileInputStream fos=new FileInputStream(path);
		 oos= new ObjectInputStream(fos);;
		
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return oos;
		
		
	}
	
	public ObjectOutputStream user_Write(File path)
	{
		ObjectOutputStream oos=null;
	//	String path="C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt";
		//f= new File(path);
		try {
		FileOutputStream fos=new FileOutputStream(path);
		 oos= new ObjectOutputStream(fos);;
		
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return oos;
		
		
	}
}
