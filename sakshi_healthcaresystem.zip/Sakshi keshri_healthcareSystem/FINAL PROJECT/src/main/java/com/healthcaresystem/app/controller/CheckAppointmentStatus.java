package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.model.Appointment;
import com.healthcaresystem.app.model.DiagnosticCenter;

public class CheckAppointmentStatus {
	
	public void status(String uid) {
		
		File path = new File("C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt");
//		FileInputStream fis = null;
//		FileOutputStream fos = null;
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		CollectionCode code=new CollectionCode();
		try {
			int i=0;
		//	fis = new FileInputStream(path);
			ObjectInputStream in =code.dc_read(path);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>) in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			int count=0;
			for (Map.Entry<String, DiagnosticCenter> m : hm.entrySet()) {
				DiagnosticCenter dc = m.getValue();
				List<Appointment> ap = dc.getAppointmentList();
				
				for (Appointment l : ap) {
					if(l.getUserId().equals(uid))
					{
						count++;
						System.out.println(++i + ". Appointment Id: "+l.getAppointmentId());
						System.out.println("\tStatus: "+l.getApproved());
						System.out.println("\tTest(s): "+l.getTest());
						System.out.println("\tLocation: "+dc.getCenterName()+","+dc.getLocation());
						System.out.println("\tDate and Time: "+l.getDatetime());
					}
				}
			}
			if(count==0)
				System.out.println("No appointment has been made!!!");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
