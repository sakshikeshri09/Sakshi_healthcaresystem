package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.dao.CollectionUtil;
import com.healthcaresystem.app.model.Appointment;
import com.healthcaresystem.app.model.DiagnosticCenter;
import com.healthcaresystem.app.model.Test;

public class AddCenter {

	public void addCenter() {
		Scanner sc = new Scanner(System.in);
		
		String centerName="";
		String location = "";
		int openingYear=0;
		List<Test> listOfTests = null;
		
		System.out.println("Enter the Diagnostic Center Name: ");
		centerName = sc.nextLine();
		System.out.println("Enter 3 tests");
		listOfTests = new ArrayList<Test>();
		
		for (int i = 0; i < 3; i++) {
			System.out.println("Enter the Test Name: ");
			String testName = sc.nextLine();
			String testId = testName+"@123";
			Test test = new Test(testId, testName);
			listOfTests.add(test);
		}
		
		System.out.println("Enter the location: ");
		location = sc.nextLine();
		
		System.out.println("Enter the Opening Year: ");
		openingYear = sc.nextInt();
		
		List<Appointment> appointmentList = new ArrayList<Appointment>();
		String centerId = "";
		centerName = centerName.trim();
		if(centerName.contains(" "))
			centerId = centerName.substring(0,3)+"@123";
		centerId = centerName+"@123";
		DiagnosticCenter dc = new DiagnosticCenter(centerName, centerId, listOfTests, appointmentList, location, openingYear);
	//		HashMap<String, DiagnosticCenter> hm = new HashMap<String, DiagnosticCenter>();
	//	ArrayList<HashMap<String, DiagnosticCenter>> al = new ArrayList<HashMap<String,DiagnosticCenter>>();
	//	al.add(0,hm);
	//	n1(al);
		
	//	CollectionUtil util=new CollectionUtil();
	//	util.dc_file_write(dc);
		n2(dc);
	}
	
	public static void n1(ArrayList<HashMap<String, DiagnosticCenter>> al) {
		File path = new File("C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		CollectionCode code=new CollectionCode();
		
		try {
			
			ObjectOutputStream out = code.dc_write(path);
			out.writeObject(al);
		} catch(Exception ex) {
			ex.printStackTrace();
		}	
	}
	
	public static void n2(DiagnosticCenter dc) {
		File path = new File("C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		
		
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		try {CollectionCode code=new CollectionCode();
			
			ObjectInputStream in =code.dc_read(path);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>)in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			hm.put(dc.getCenterId(),dc);
			al.set(0,hm);
			System.out.println("Diagnostic Center Id: "+dc.getCenterId());
			System.out.println("New Diagnostic Center added Successfully!!!");
			in.close();
		//	fis.close();
			
			
			ObjectOutputStream out = code.dc_write(path);
			out.writeObject(al);
			out.close();
		//	fos.close();
		}  catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}
