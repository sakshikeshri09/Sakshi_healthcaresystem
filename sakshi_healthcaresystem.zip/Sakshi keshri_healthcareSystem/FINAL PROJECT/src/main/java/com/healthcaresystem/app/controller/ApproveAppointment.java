package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.model.Appointment;
import com.healthcaresystem.app.model.DiagnosticCenter;
import com.healthcaresystem.app.model.User;

public class ApproveAppointment {
	
	public void approve() {
		
		Scanner sc = new Scanner(System.in);
		File path = new File("C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		//FileInputStream fis = null;
		//	FileOutputStream fos = null;
		
		CollectionCode code=new CollectionCode();
		
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		
		try {
			
		//	fis = new FileInputStream(path);
			ObjectInputStream in = code.dc_read(path);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>) in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			
			System.out.println("\n---------------------------Change Appointment Status------------------------");
			
			int count=0;
			for (Map.Entry<String, DiagnosticCenter> m : hm.entrySet()) {
				DiagnosticCenter dc = m.getValue();
				List<Appointment> ap = dc.getAppointmentList();
				
				for (Appointment l : ap) {
					if(l.getApproved()==false)
					{
						count++;
						System.out.println(l);
					}
				}
				
				if(count>0) 
				{
					System.out.println("Do you want to change status:");
					System.out.println("1. Yes");
					System.out.println("2. No");
					int n = sc.nextInt();

					switch (n) {

					case 1:
						
						System.out.println("Enter the appointment id: ");
						sc.nextLine();
						String aid = sc.nextLine();

						int flag = 0;
						for (Appointment a : ap) {
							if (a.getAppointmentId().equals(aid)) {
								a.setApproved(true);
								flag = 1;
								break;
							}
						}
						
						if (flag == 0) {
							System.out.println("Entered Wrong Appointment Id!!!");
							approve();
						} 
						else
							dc.setAppointmentList(ap);
						System.out.println("DONE!!");
						in.close();
					//	fis.close();

					//	fos = new FileOutputStream(path);
						ObjectOutputStream out =code.user_Write(path);
						out.writeObject(al);
						out.close();
					//	fos.close();
						break;

					case 2:
						
						break;

					default:
						
						System.out.println("Wrong Input!!!");
						approve();
						break;
					}
				}
			}
			
			if(count==0)
			{
				System.out.println("No appointments are pending to get approved!!!");
			}
			
		} catch(InputMismatchException ex) {
			System.out.println("Entered wrong input!!!");
			approve();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
