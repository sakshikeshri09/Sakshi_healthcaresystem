package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.model.DiagnosticCenter;
import com.healthcaresystem.app.model.Test;

public class AddTest {

	public void addTest() {
		
		ViewCentersDetails view = new ViewCentersDetails();
		int count = view.displayCenter();
		
		if (count>0) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the Diagnostic Center Id: ");
			String centerId = sc.next();
			File path = new File("C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt");
			CollectionCode code=new CollectionCode();
			ArrayList<HashMap<String, DiagnosticCenter>> al = null;
			try {
				
				ObjectInputStream in = code.user_Read(path);
				al = (ArrayList<HashMap<String, DiagnosticCenter>>) in.readObject();
				HashMap<String, DiagnosticCenter> hm = al.get(0);

				if (hm.containsKey(centerId)) {
					System.out.println("Enter the number of test(s) to be added: ");
					int n = sc.nextInt();
					sc.nextLine();
					DiagnosticCenter dc = hm.get(centerId);
					List<Test> test = dc.getListOfTests();
					for (int i = 0; i < n; i++) {
						System.out.println("Enter the test name: ");
						String testName = sc.nextLine();
						String testId = testName + "@123";
						Test t = new Test(testId, testName);
						test.add(t);
					}
					dc.setListOfTests(test);
					hm.put(centerId, dc);
					al.set(0, hm);
					in.close();
				//	fis.close();
				//	fos = new FileOutputStream(path);
					ObjectOutputStream out = code.user_Write(path);
					out.writeObject(al);
					out.close();
				//	fos.close();
					System.out.println("New Test details has been successfully added!!!");
				} else {
					System.out.println("Diagnostic Center with Id: " + centerId + " doesn't exist!!!");
					System.out.println("Please Try Again!!!");
					addTest();
				}
			} catch(InputMismatchException ex) {
				System.out.println("Entered wrong input!!!");
				addTest();
			}
			catch (Exception ex) {
				ex.printStackTrace();
			} 
		}
		else
			System.out.println("SORRY, no diagnostic centers has been entered by the admin!!!");
	}
}
