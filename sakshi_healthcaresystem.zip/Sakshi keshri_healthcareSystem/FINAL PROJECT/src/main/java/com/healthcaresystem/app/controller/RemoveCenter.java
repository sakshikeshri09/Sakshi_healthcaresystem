package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.model.DiagnosticCenter;
import com.healthcaresystem.app.model.User;

public class RemoveCenter {

	public void removeCenter() {
		
		ViewCentersDetails view = new ViewCentersDetails();
		int count = view.displayCenter();
		
		if (count>0) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the Diagnostic Center Id: ");
			String centerId = sc.next();
			File path = new File(
					"C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt");
		//	FileInputStream fis = null;
		//	FileOutputStream fos = null;
			
			CollectionCode code=new CollectionCode();
			ArrayList<HashMap<String, DiagnosticCenter>> al = null;
			try {
			//	fis = new FileInputStream(path);
				ObjectInputStream in = code.user_Read(path);
				al = (ArrayList<HashMap<String, DiagnosticCenter>>) in.readObject();
				HashMap<String, DiagnosticCenter> hm = al.get(0);

				if (hm.containsKey(centerId)) {
					hm.remove(centerId);
					al.set(0, hm);
					in.close();
		//			fis.close();
		//			fos = new FileOutputStream(path);
					ObjectOutputStream out =code.user_Write(path);
					out.writeObject(al);
					out.close();
		//			fos.close();
					System.out.println("Diagnostic Center has been successfully removed!!!");
				} else {
					System.out.println("Diagnostic Center with Id: " + centerId + " doesn't exist!!!");
					System.out.println("Please Try Again!!!");
					removeCenter();
				}
			} catch(InputMismatchException ex) {
				System.out.println("Entered wrong input!!!");
				removeCenter();
			}
			catch (Exception ex) {
				ex.printStackTrace();
			} 
		}
		else
			System.out.println("SORRY, no diagnostic centers has been entered by the admin!!!");
	}
}
