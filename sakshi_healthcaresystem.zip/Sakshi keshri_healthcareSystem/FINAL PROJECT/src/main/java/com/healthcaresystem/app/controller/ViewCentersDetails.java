package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.model.Appointment;
import com.healthcaresystem.app.model.DiagnosticCenter;

public class ViewCentersDetails {

	public int displayCenter() {
		
		int count=0;
		File path = new File("C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt");
//		FileInputStream fis = null;
		CollectionCode code=new CollectionCode();
		ArrayList<HashMap<String, DiagnosticCenter>> al = null;
		
		try {
		//	fis = new FileInputStream(path);
			ObjectInputStream in = code.user_Read(path);
			al = (ArrayList<HashMap<String, DiagnosticCenter>>)in.readObject();
			HashMap<String, DiagnosticCenter> hm = al.get(0);
			
			for (Map.Entry<String, DiagnosticCenter> m : hm.entrySet()) {
				count++;
				System.out.println(m.getValue());
			}
			
			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return count;
	}
}
