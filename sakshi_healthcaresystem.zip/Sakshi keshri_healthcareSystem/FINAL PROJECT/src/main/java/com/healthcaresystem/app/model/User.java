package com.healthcaresystem.app.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

public class User implements Serializable {

	private String userId;
	private List<DiagnosticCenter> centerList;
	private String userPassword;
	private String userName;
	private BigInteger contactNo;
	private String userEmail;
	private String gender;
	private int age;
	
	public String getUserId() {
		return userId;
	}
	public User(String userId, List<DiagnosticCenter> centerList, String userPassword, String userName,
			BigInteger contactNo, String userEmail, String gender, int age) {
		super();
		this.userId = userId;
		this.centerList = centerList;
		this.userPassword = userPassword;
		this.userName = userName;
		this.contactNo = contactNo;
		this.userEmail = userEmail;
		this.gender = gender;
		this.age = age;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<DiagnosticCenter> getCenterList() {
		return centerList;
	}
	public void setCenterList(List<DiagnosticCenter> centerList) {
		this.centerList = centerList;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public BigInteger getContactNo() {
		return contactNo;
	}
	public void setContactNo(BigInteger contactNo) {
		this.contactNo = contactNo;
	}
	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", centerList=" + centerList + ", userPassword=" + userPassword
				+ ", userName=" + userName + ", contactNo=" + contactNo + ", userEmail=" + userEmail + ", gender="
				+ gender + ", age=" + age + "]";
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
}
