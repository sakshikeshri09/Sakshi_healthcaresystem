package com.healthcaresystem.app.controller;

import java.io.File;
import com.healthcaresystem.app.dao.CollectionUtil;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.model.DiagnosticCenter;
import com.healthcaresystem.app.model.User;

public class Register {

public void register() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\n--------------------------Fill up the following details---------------------");
		
		String name = "";
		String pass = "";
		BigInteger phn = null;
		String email = "";
		String gender = "";
		int age = 0;
		
		aa:
		do {
			System.out.println("Enter your name: ");
			name = sc.nextLine();
			if(name_validate(name.trim()))
			{
				do {
					System.out.println("Enter your password: ");
					pass = sc.nextLine();
					if (pass_validate(pass)) 
					{	
						do {
							System.out.println("Enter your phone no.: ");
							phn = sc.nextBigInteger();
							if (phn_validate(phn)) 
							{
								do {
									System.out.println("Enter your email-id: ");
									email = sc.next();
									if(email_validate(email))
									{
										do {
											System.out.println("Enter your gender(M/F): ");
											gender = sc.next();
											if (gender.equals("M") || gender.equals("F")) 
											{
												do {
													System.out.println("Enter your age: ");
													age = sc.nextInt();
													if (age > 0 && age < 110)
														break aa;
													else
														System.out.println("INVALID!! Enter a valid age number.");
												} while (true);
											}
											else
												System.out.println("INVALID!! Enter your gender properly in format of M/F");
										} while (true);
									} 
									else
										System.out.println("INVALID!! You have entered an invalid email-id.");
								} while (true);
							} 
							else
								System.out.println("INVALID!! Please enter your valid 10-digit number.");
						} while (true);
					} 
					else
						System.out.println("INVALID!! Your password should contains one number, one alphabet, one special character and 8 letters minimum.");
				} while (true);
			}
			else
				System.out.println("INVALID!! Enter your valid name. No special characters and first letter should be capital.");
		} while (true);
		
		List<DiagnosticCenter> centerList = null;
		String userId ="";
		if(name.contains(" "))
			userId = name.substring(0,2)+name.charAt(name.length()-2)+name.charAt(name.length()-3)+"@123";
		else
			userId = name+"@123";
		User user = new User(userId, centerList, pass, name, phn, email, gender, age);
//	HashMap<String, User> hm = new HashMap<String, User>();
//		ArrayList<HashMap<String, User>> al = new ArrayList<HashMap<String,User>>();
//		al.add(0,hm);
//		m1(al);
//		CollectionUtil util=new CollectionUtil();
//		util.user_file_write(user);
		m2(user);
		
	}
	
	public static void m2(User user) {
		File path = new File("C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\UserDetails.txt");
//		FileInputStream fis = null;
	//	FileOutputStream fos = null;
		ArrayList<HashMap<String, User>> al = null;
		CollectionCode code=new CollectionCode();
		try {
		//	fis = new FileInputStream(path);
			ObjectInputStream in =code.user_Read(path);
			al = (ArrayList<HashMap<String, User>>) in.readObject();
			HashMap<String, User> hm = al.get(0);
			hm.put(user.getUserId(),user);
			al.set(0,hm);
			System.out.println(al);
			System.out.println("Your User Id: "+user.getUserId());
			System.out.println("Your Passowrd: "+user.getUserPassword());
			System.out.println("Registered Successfully!!!");
			in.close();
			//fis.close();
			
		//	fos = new FileOutputStream(path);
			ObjectOutputStream out =code.user_Write(path);
			out.writeObject(al);
			out.close();
		//	fos.close();
			return;
		}  catch(Exception ex) {
			ex.printStackTrace();
		}
	}
			
	public boolean name_validate(String name) {
		if(name.charAt(0)>='A'&& name.charAt(0)<='Z')
		{
			String regex = "^[a-zA-Z\\s]*$";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(name); 
			if(matcher.matches())
				return true;	
		}
		return false;
	}
	
	public boolean pass_validate(String pass) {
		if(pass.length() >=8 && pass.length()<=14 ) {
			int num=0;
			int alpha=0;
			int spec=0;
			for(int i=0;i<pass.length();i++) {
				if((pass.charAt(i)>=65 && pass.charAt(i)<=90) || (pass.charAt(i)>=97 && pass.charAt(i)<=122))
				{
					alpha++;
				}
				else if(pass.charAt(i)>=48 && pass.charAt(i)<=57)
				{
					num++;
				}
				else
					spec++;
			}
			
			if(alpha>1 && num>0 && spec>0)
				return true;
		}
		return false;
	}
		
	public boolean phn_validate(BigInteger phn) {
		String phns = phn.toString();
		if(phns.length()==10)
			return true;
		return false;
	}
	
	public boolean email_validate(String email) {
		String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
		 
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(email); 
		if(matcher.matches())
			return true;
		return false;
	}
	

	public static void m1(ArrayList<HashMap<String, User>> al) {
		File path = new File("C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\UserDetails.txt");
	//	FileOutputStream fos = null;
		CollectionCode code=new CollectionCode();
		try {
			//fos = new FileOutputStream(path);
			ObjectOutputStream out = code.user_Write(path);
			out.writeObject(al);
		} catch(Exception ex) {
			ex.printStackTrace();
		}	
	}
}
