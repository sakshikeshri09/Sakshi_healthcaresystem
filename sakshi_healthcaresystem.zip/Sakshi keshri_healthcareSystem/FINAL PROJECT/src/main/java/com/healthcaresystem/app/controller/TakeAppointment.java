package com.healthcaresystem.app.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.healthcaresystem.app.dao.CollectionCode;
import com.healthcaresystem.app.model.Appointment;
import com.healthcaresystem.app.model.DiagnosticCenter;
import com.healthcaresystem.app.model.Test;

public class TakeAppointment {

	public void takeAppointment(String uid) {
		
		ViewCentersDetails view = new ViewCentersDetails();
		int count = view.displayCenter();
		
		if (count>0) {
			Scanner sc = new Scanner(System.in);
			System.out.println("\nEnter the Diagnostic Center Id: ");
			String centerId = sc.next();
			File path = new File("C:\\Users\\sakshi\\Desktop\\FINAL PROJECT\\src\\main\\resources\\DiagnosticCenterDetails.txt");
	
			//FileInputStream fis = null;
	//		FileOutputStream fos = null;
			CollectionCode code=new CollectionCode();
			ArrayList<HashMap<String, DiagnosticCenter>> al = null;
			try {
			//	fis = new FileInputStream(path);
				ObjectInputStream in = code.user_Read(path);
				al = (ArrayList<HashMap<String, DiagnosticCenter>>) in.readObject();
				HashMap<String, DiagnosticCenter> hm = al.get(0);

				if (hm.containsKey(centerId)) {
					DiagnosticCenter dc = hm.get(centerId);
					List<Test> test = dc.getListOfTests();

					System.out.println("\nTest(s) List: ");
					int n = 0;
					for (Test i : test) {
						System.out.println(++n + ". " + i.getTestId() + " " + i.getTestName());
					}

					System.out.println("\nEnter the test id from above list: ");
					sc.nextLine();
					String testId = sc.nextLine();

					List<Test> t = new ArrayList<Test>();
					int flag = 0;
					for (Test i : test) {
						if (i.getTestId().equals(testId)) {
							flag = 1;
							t.add(i);
							break;
						}
					}

					if (flag == 0) {
						System.out.println("\nThe Test with Id: " + testId + " doesn't exist!!!");
						System.out.println("Please try again!!!");
						takeAppointment(uid);
					}

					else {
						String dd;
						String time;
						do {
							System.out.println("Enter date in format DD-MM-YYYY");
							dd = sc.next();
							System.out.println("Enter time in 24hrs format between 10:00 to 19:00");
							time = sc.next();
							if (date_time_validate(dd, time)) {
								String date = dd + " " + time;
								SimpleDateFormat sd = new SimpleDateFormat("dd-MM-yyyy kk:mm");
								Date d = sd.parse(date);
								String appointmentId = uid + "#123";
								boolean approved = false;
								Appointment appoint = new Appointment(uid, appointmentId, t, d, approved, dc);
								List<Appointment> ap = new ArrayList<Appointment>();
								ap.add(appoint);
								dc.setAppointmentList(ap);
								hm.put(dc.getCenterId(), dc);
								al.set(0, hm);
								in.close();
							//	fis.close();
								System.out.println("Appointment Request made Successfully!!!");
							//	fos = new FileOutputStream(path);
								ObjectOutputStream out =code.user_Write(path);
								out.writeObject(al);
								out.close();
							//	fos.close();
							} 
							else
								System.out.println("Enter the correct date and time!!!");
						} while (!date_time_validate(dd, time));
					}
				} else {
					System.out.println("\nDiagnostic Center with Id: " + centerId + " doesn't exist!!!");
					System.out.println("Please Try Again!!!\n");
					takeAppointment(uid);
				}

			} catch(InputMismatchException ex) {
				System.out.println("Entered wrong input!!!");
				takeAppointment(uid);
			}
			catch (Exception e) {
				e.printStackTrace();
			} 
		}
		else
			System.out.println("SORRY, no diagnostic centers has been entered by the admin!!!");
	}
	
	public boolean date_time_validate(String dd, String time) throws ParseException {
		LocalDateTime now = LocalDateTime.now();
		SimpleDateFormat sd_1 = new SimpleDateFormat("dd-MM-yyyy");
		SimpleDateFormat sd_2 = new SimpleDateFormat("kk:mm");
		Date dt_1 = sd_1.parse(dd);
		
		Date dt_2 = new Date();
		String current = sd_1.format(dt_2);
		Date dt_current = sd_1.parse(current);
		if(dt_1.compareTo(dt_current) > 0 )
			return true;
		
		else if(dt_1.compareTo(dt_current) == 0)
		{
			String t = sd_2.format(dt_2);
			LocalTime time1 = LocalTime.parse(time);
			LocalTime time2 = LocalTime.parse("10:00:00");
			LocalTime time3 = LocalTime.parse("19:00:00");
			
			if((time1.compareTo(time2) > 0) && (time1.compareTo(time3) < 0))
				return true;
		}
		
		return false;
	}
}
